package com.example.postapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostApiApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring application context starts successfully
        // with all Controller -> Service -> Repository beans wired.
    }

}
