package com.example.postapi.entity;

/**
 * Lifecycle status of a Post.
 */
public enum PostStatus {
    DRAFT,
    SCHEDULED,
    PUBLISHED
}
