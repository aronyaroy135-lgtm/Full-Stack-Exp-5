package com.example.postapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Standardized response envelope returned by every API endpoint.
 * Guarantees a predictable structure for both success and error
 * responses, which simplifies frontend integration.
 *
 * Example success:
 * {
 *   "success": true,
 *   "message": "Post created successfully",
 *   "data": { ... },
 *   "timestamp": "2026-09-15T10:15:30"
 * }
 *
 * Example error:
 * {
 *   "success": false,
 *   "message": "Validation failed",
 *   "errors": { "title": "Title must not be blank" },
 *   "timestamp": "2026-09-15T10:15:30"
 * }
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {

    private boolean success;
    private String message;
    private T data;
    private Object errors;

    @Builder.Default
    private LocalDateTime timestamp = LocalDateTime.now();

    public static <T> ApiResponse<T> success(String message, T data) {
        return ApiResponse.<T>builder()
                .success(true)
                .message(message)
                .data(data)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static <T> ApiResponse<T> error(String message, Object errors) {
        return ApiResponse.<T>builder()
                .success(false)
                .message(message)
                .errors(errors)
                .timestamp(LocalDateTime.now())
                .build();
    }
}
