package com.example.postapi.exception;

/**
 * Thrown when a requested resource (e.g. a Post by id) does not exist.
 * Handled globally by GlobalExceptionHandler and translated into a
 * standardized 404 API response.
 */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
