package com.example.postapi.service.impl;

import com.example.postapi.dto.PostRequestDTO;
import com.example.postapi.dto.PostResponseDTO;
import com.example.postapi.entity.Post;
import com.example.postapi.entity.PostStatus;
import com.example.postapi.exception.ResourceNotFoundException;
import com.example.postapi.repository.PostRepository;
import com.example.postapi.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service layer implementation - contains the business logic for
 * Post CRUD operations and scheduling, sitting between the
 * Controller layer and the Repository layer.
 */
@Service
@RequiredArgsConstructor
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;

    @Override
    public PostResponseDTO createPost(PostRequestDTO requestDTO) {
        Post post = Post.builder()
                .title(requestDTO.getTitle())
                .content(requestDTO.getContent())
                .author(requestDTO.getAuthor())
                .scheduledAt(requestDTO.getScheduledAt())
                .status(requestDTO.getScheduledAt() != null ? PostStatus.SCHEDULED : PostStatus.DRAFT)
                .build();

        Post saved = postRepository.save(post);
        return mapToResponseDTO(saved);
    }

    @Override
    public PostResponseDTO getPostById(Long id) {
        Post post = findPostOrThrow(id);
        return mapToResponseDTO(post);
    }

    @Override
    public List<PostResponseDTO> getAllPosts() {
        return postRepository.findAll()
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<PostResponseDTO> getPostsByStatus(String status) {
        PostStatus postStatus;
        try {
            postStatus = PostStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Invalid status value. Allowed values: DRAFT, SCHEDULED, PUBLISHED");
        }
        return postRepository.findByStatus(postStatus)
                .stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public PostResponseDTO updatePost(Long id, PostRequestDTO requestDTO) {
        Post post = findPostOrThrow(id);

        post.setTitle(requestDTO.getTitle());
        post.setContent(requestDTO.getContent());
        post.setAuthor(requestDTO.getAuthor());
        post.setScheduledAt(requestDTO.getScheduledAt());

        if (requestDTO.getScheduledAt() != null && post.getStatus() != PostStatus.PUBLISHED) {
            post.setStatus(PostStatus.SCHEDULED);
        }

        Post updated = postRepository.save(post);
        return mapToResponseDTO(updated);
    }

    @Override
    public void deletePost(Long id) {
        Post post = findPostOrThrow(id);
        postRepository.delete(post);
    }

    @Override
    public PostResponseDTO publishPost(Long id) {
        Post post = findPostOrThrow(id);
        post.setStatus(PostStatus.PUBLISHED);
        post.setScheduledAt(post.getScheduledAt() == null ? LocalDateTime.now() : post.getScheduledAt());
        Post updated = postRepository.save(post);
        return mapToResponseDTO(updated);
    }

    // ---- helpers ----

    private Post findPostOrThrow(Long id) {
        return postRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found with id: " + id));
    }

    private PostResponseDTO mapToResponseDTO(Post post) {
        return PostResponseDTO.builder()
                .id(post.getId())
                .title(post.getTitle())
                .content(post.getContent())
                .author(post.getAuthor())
                .scheduledAt(post.getScheduledAt())
                .status(post.getStatus())
                .createdAt(post.getCreatedAt())
                .updatedAt(post.getUpdatedAt())
                .build();
    }
}
