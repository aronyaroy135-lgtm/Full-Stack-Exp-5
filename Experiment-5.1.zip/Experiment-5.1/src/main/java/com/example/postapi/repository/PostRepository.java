package com.example.postapi.repository;

import com.example.postapi.entity.Post;
import com.example.postapi.entity.PostStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Repository layer - handles direct interaction with the database.
 * Extending JpaRepository gives CRUD operations out of the box,
 * plus derived query methods declared below.
 */
public interface PostRepository extends JpaRepository<Post, Long> {

    List<Post> findByStatus(PostStatus status);

    List<Post> findByAuthorIgnoreCase(String author);
}
