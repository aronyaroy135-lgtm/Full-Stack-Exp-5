package com.example.postapi.service;

import com.example.postapi.dto.PostRequestDTO;
import com.example.postapi.dto.PostResponseDTO;

import java.util.List;

/**
 * Service layer contract - defines the business operations
 * available for the Post resource. The controller depends on
 * this abstraction rather than the implementation directly.
 */
public interface PostService {

    PostResponseDTO createPost(PostRequestDTO requestDTO);

    PostResponseDTO getPostById(Long id);

    List<PostResponseDTO> getAllPosts();

    List<PostResponseDTO> getPostsByStatus(String status);

    PostResponseDTO updatePost(Long id, PostRequestDTO requestDTO);

    void deletePost(Long id);

    PostResponseDTO publishPost(Long id);
}
