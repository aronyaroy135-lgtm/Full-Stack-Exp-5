package com.example.postapi.controller;

import com.example.postapi.dto.ApiResponse;
import com.example.postapi.dto.PostRequestDTO;
import com.example.postapi.dto.PostResponseDTO;
import com.example.postapi.service.PostService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller layer - handles incoming HTTP requests for the Post
 * resource, delegates business logic to the Service layer, and
 * wraps every response in the standardized ApiResponse envelope.
 *
 * Base URI: /api/v1/posts
 */
@RestController
@RequestMapping("/api/v1/posts")
@RequiredArgsConstructor
@CrossOrigin(origins = "*", maxAge = 3600) // fine-grained CORS also configured globally in CorsConfig
public class PostController {

    private final PostService postService;

    /** CREATE - POST /api/v1/posts */
    @PostMapping
    public ResponseEntity<ApiResponse<PostResponseDTO>> createPost(
            @Valid @RequestBody PostRequestDTO requestDTO) {
        PostResponseDTO created = postService.createPost(requestDTO);
        return new ResponseEntity<>(
                ApiResponse.success("Post created successfully", created),
                HttpStatus.CREATED);
    }

    /** READ (single) - GET /api/v1/posts/{id} */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PostResponseDTO>> getPostById(@PathVariable Long id) {
        PostResponseDTO post = postService.getPostById(id);
        return ResponseEntity.ok(ApiResponse.success("Post retrieved successfully", post));
    }

    /** READ (all) - GET /api/v1/posts */
    @GetMapping
    public ResponseEntity<ApiResponse<List<PostResponseDTO>>> getAllPosts() {
        List<PostResponseDTO> posts = postService.getAllPosts();
        return ResponseEntity.ok(ApiResponse.success("Posts retrieved successfully", posts));
    }

    /** READ (filtered by status) - GET /api/v1/posts/status/{status} */
    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<PostResponseDTO>>> getPostsByStatus(
            @PathVariable String status) {
        List<PostResponseDTO> posts = postService.getPostsByStatus(status);
        return ResponseEntity.ok(ApiResponse.success("Posts retrieved successfully", posts));
    }

    /** UPDATE - PUT /api/v1/posts/{id} */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<PostResponseDTO>> updatePost(
            @PathVariable Long id,
            @Valid @RequestBody PostRequestDTO requestDTO) {
        PostResponseDTO updated = postService.updatePost(id, requestDTO);
        return ResponseEntity.ok(ApiResponse.success("Post updated successfully", updated));
    }

    /** DELETE - DELETE /api/v1/posts/{id} */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deletePost(@PathVariable Long id) {
        postService.deletePost(id);
        return ResponseEntity.ok(ApiResponse.success("Post deleted successfully", null));
    }

    /** SCHEDULING ACTION - PATCH /api/v1/posts/{id}/publish */
    @PatchMapping("/{id}/publish")
    public ResponseEntity<ApiResponse<PostResponseDTO>> publishPost(@PathVariable Long id) {
        PostResponseDTO published = postService.publishPost(id);
        return ResponseEntity.ok(ApiResponse.success("Post published successfully", published));
    }
}
