# Post API — Spring Boot REST API Practical

Designing and implementing RESTful APIs using Spring Boot with proper
validation, standardized responses, and a scalable layered architecture.

## Project Structure (Layered Architecture)

```
src/main/java/com/example/postapi/
├── PostApiApplication.java        # Application entry point
├── controller/
│   └── PostController.java        # Handles HTTP requests
├── service/
│   ├── PostService.java           # Business logic contract
│   └── impl/PostServiceImpl.java  # Business logic implementation
├── repository/
│   └── PostRepository.java        # Database access (Spring Data JPA)
├── entity/
│   ├── Post.java                  # JPA entity
│   └── PostStatus.java            # DRAFT / SCHEDULED / PUBLISHED
├── dto/
│   ├── PostRequestDTO.java        # Incoming request + Bean Validation
│   ├── PostResponseDTO.java       # Outgoing response shape
│   └── ApiResponse.java           # Standardized response envelope
├── exception/
│   ├── ResourceNotFoundException.java
│   └── GlobalExceptionHandler.java
└── config/
    └── CorsConfig.java            # CORS configuration
```

## Software Requirements

- Java (JDK 17+)
- Maven 3.8+
- IDE (IntelliJ / Eclipse / VS Code)
- Postman or any API testing tool

## How to Run

```bash
# 1. Extract the zip and move into the project folder
cd post-api

# 2. Build the project
mvn clean install

# 3. Run the application
mvn spring-boot:run
```

The API will start at: `http://localhost:8080`

H2 in-memory database console: `http://localhost:8080/h2-console`
(JDBC URL: `jdbc:h2:mem:postdb`, username: `sa`, password: empty)

## Standardized Response Format

**Success:**
```json
{
  "success": true,
  "message": "Post created successfully",
  "data": { "id": 1, "title": "First Post", "status": "DRAFT" },
  "timestamp": "2026-09-15T10:15:30"
}
```

**Validation Error:**
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": { "title": "Title must not be blank" },
  "timestamp": "2026-09-15T10:15:30"
}
```

## API Endpoints

| Method | Endpoint                         | Description                          |
|--------|-----------------------------------|---------------------------------------|
| POST   | `/api/v1/posts`                  | Create a new post                    |
| GET    | `/api/v1/posts`                  | Get all posts                        |
| GET    | `/api/v1/posts/{id}`             | Get a post by id                     |
| GET    | `/api/v1/posts/status/{status}`  | Get posts by status (DRAFT/SCHEDULED/PUBLISHED) |
| PUT    | `/api/v1/posts/{id}`             | Update an existing post              |
| DELETE | `/api/v1/posts/{id}`             | Delete a post                        |
| PATCH  | `/api/v1/posts/{id}/publish`     | Publish a post immediately           |

### Sample Request Body (POST / PUT)

```json
{
  "title": "Spring Boot REST API",
  "content": "Learning to build validated, standardized REST APIs.",
  "author": "Jane Doe",
  "scheduledAt": "2026-12-25T09:00:00"
}
```

`scheduledAt` is optional. If provided, it must be a future date-time
(enforced by `@Future`) and the post's status will automatically become
`SCHEDULED`. Omit it to create a `DRAFT` post.

### Validation Rules (Bean Validation)

| Field        | Rule                                      |
|--------------|--------------------------------------------|
| title        | `@NotBlank`, `@Size(min=3, max=150)`       |
| content      | `@NotBlank`, `@Size(max=5000)`             |
| author       | `@NotBlank`, `@Size(min=2, max=100)`       |
| scheduledAt  | `@Future` (optional field)                 |

## CORS

Configured globally in `CorsConfig.java` for all `/api/**` routes,
allowing GET, POST, PUT, PATCH, DELETE and OPTIONS from any origin —
enabling secure frontend-backend communication across different origins
(e.g. a React app running on `http://localhost:3000`).

## Testing with Postman

1. Import the endpoints above into a Postman collection.
2. Set `Content-Type: application/json` for POST/PUT requests.
3. Try invalid input (e.g. blank title) to see the standardized
   validation error response.
4. Try `GET /api/v1/posts/999` to see the standardized 404 error.

## Expected Outcome

- Functional REST APIs for CRUD operations on Posts
- Validated request handling using Bean Validation
- Consistent API response structure via `ApiResponse<T>`
- Secure frontend-backend communication via CORS
- Clean layered architecture: Controller → Service → Repository
