package com.example.exceptionlogging.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * Assigns a correlation ID to every incoming request:
 *  - reuses the "X-Correlation-Id" header if the caller already supplied one
 *    (useful when this service is called from another service in a chain),
 *  - otherwise generates a fresh UUID.
 *
 * The ID is:
 *  1. Put into SLF4J's MDC so it automatically appears in EVERY log line
 *     printed while this request is being processed (see logback-spring.xml).
 *  2. Echoed back on the response header so the client can correlate it too.
 *
 * Runs first in the filter chain (@Order = highest precedence) so the ID is
 * available before any other filter/interceptor/controller code executes.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter extends OncePerRequestFilter {

    public static final String CORRELATION_ID_HEADER = "X-Correlation-Id";
    public static final String MDC_KEY = "correlationId";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String correlationId = request.getHeader(CORRELATION_ID_HEADER);
        if (correlationId == null || correlationId.isBlank()) {
            correlationId = UUID.randomUUID().toString();
        }

        try {
            MDC.put(MDC_KEY, correlationId);
            response.setHeader(CORRELATION_ID_HEADER, correlationId);
            filterChain.doFilter(request, response);
        } finally {
            // Always clear MDC after the request completes, otherwise the value
            // can leak into unrelated requests handled by a reused thread pool.
            MDC.remove(MDC_KEY);
        }
    }
}
