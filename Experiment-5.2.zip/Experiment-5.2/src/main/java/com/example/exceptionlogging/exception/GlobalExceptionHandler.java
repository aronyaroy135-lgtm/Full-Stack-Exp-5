package com.example.exceptionlogging.exception;

import com.example.exceptionlogging.dto.ErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Centralized exception handling for the whole application.
 *
 * Every handler here does two things:
 *  1. Logs the exception with the current correlation ID (added automatically
 *     to the log pattern via MDC — see CorrelationIdFilter + logback-spring.xml).
 *  2. Returns a uniform ErrorResponse so API consumers get a predictable shape
 *     regardless of which exception was thrown.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // ---- 404: resource not found -----------------------------------------
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFound(
            ResourceNotFoundException ex, HttpServletRequest request) {

        log.warn("Resource not found: {}", ex.getMessage());

        ErrorResponse body = buildError(HttpStatus.NOT_FOUND, ex.getMessage(), request.getRequestURI(), null);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    // ---- 400: custom business validation -----------------------------------
    @ExceptionHandler(CustomValidationException.class)
    public ResponseEntity<ErrorResponse> handleCustomValidation(
            CustomValidationException ex, HttpServletRequest request) {

        log.warn("Business validation failed: {}", ex.getMessage());

        ErrorResponse body = buildError(HttpStatus.BAD_REQUEST, ex.getMessage(), request.getRequestURI(), null);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    // ---- 400: bean validation failures (@Valid on request bodies) ----------
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers,
            HttpStatusCode status, WebRequest request) {

        List<String> details = ex.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + ": " + fe.getDefaultMessage())
                .collect(Collectors.toList());

        log.warn("Request validation failed: {}", details);

        String path = request.getDescription(false).replace("uri=", "");
        ErrorResponse body = buildError(HttpStatus.BAD_REQUEST, "Validation failed for request body", path, details);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    // ---- 405: wrong HTTP method ---------------------------------------------
    @ExceptionHandler(org.springframework.web.HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorResponse> handleMethodNotAllowed(
            org.springframework.web.HttpRequestMethodNotSupportedException ex, HttpServletRequest request) {

        log.warn("Method not allowed: {}", ex.getMessage());

        ErrorResponse body = buildError(HttpStatus.METHOD_NOT_ALLOWED, ex.getMessage(), request.getRequestURI(), null);
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(body);
    }

    // ---- 500: anything else (fallback / catch-all) ---------------------------
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(
            Exception ex, HttpServletRequest request) {

        // Full stack trace at ERROR level — this is what you search for in the
        // logs using the correlation ID printed in the response body.
        log.error("Unhandled exception occurred", ex);

        ErrorResponse body = buildError(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "An unexpected error occurred. Please contact support with the correlation ID.",
                request.getRequestURI(),
                null);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    // ---- helper --------------------------------------------------------------
    private ErrorResponse buildError(HttpStatus status, String message, String path, List<String> details) {
        return ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(status.value())
                .error(status.getReasonPhrase())
                .message(message)
                .path(path)
                .correlationId(MDC.get("correlationId"))
                .details(details)
                .build();
    }
}
