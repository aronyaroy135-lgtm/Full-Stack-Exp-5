package com.example.exceptionlogging.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Logs the lifecycle of every request handled by a controller:
 *  - preHandle:        method + URI + client IP, records the start time
 *  - afterCompletion:   final HTTP status + execution time in ms (and the
 *                        exception, if the request ended in one)
 *
 * Because this runs inside the same thread as CorrelationIdFilter, the
 * correlation ID already present in MDC is automatically included in
 * every log line below via the logback pattern.
 */
@Component
public class RequestLoggingInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingInterceptor.class);
    private static final String START_TIME_ATTR = "requestStartTime";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        request.setAttribute(START_TIME_ATTR, System.currentTimeMillis());
        log.info("Incoming request -> {} {} from {}",
                request.getMethod(), request.getRequestURI(), request.getRemoteAddr());
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                 Object handler, Exception ex) {
        long startTime = (long) request.getAttribute(START_TIME_ATTR);
        long duration = System.currentTimeMillis() - startTime;

        if (ex != null) {
            log.error("Completed request -> {} {} | status={} | durationMs={} | endedWithException={}",
                    request.getMethod(), request.getRequestURI(), response.getStatus(), duration,
                    ex.getClass().getSimpleName());
        } else {
            log.info("Completed request -> {} {} | status={} | durationMs={}",
                    request.getMethod(), request.getRequestURI(), response.getStatus(), duration);
        }
    }
}
