package com.example.exceptionlogging.exception;

/**
 * Thrown when a requested resource (e.g. a User) cannot be found.
 * Handled centrally by GlobalExceptionHandler -> HTTP 404.
 */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
