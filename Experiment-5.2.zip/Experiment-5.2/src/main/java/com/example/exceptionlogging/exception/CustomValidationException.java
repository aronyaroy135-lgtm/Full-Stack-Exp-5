package com.example.exceptionlogging.exception;

/**
 * Thrown for business-rule / manual validation failures that are
 * not already covered by Bean Validation (@Valid).
 * Handled centrally by GlobalExceptionHandler -> HTTP 400.
 */
public class CustomValidationException extends RuntimeException {

    public CustomValidationException(String message) {
        super(message);
    }
}
