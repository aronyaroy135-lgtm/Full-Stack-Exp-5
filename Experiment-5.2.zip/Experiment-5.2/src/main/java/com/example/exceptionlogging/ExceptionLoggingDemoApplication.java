package com.example.exceptionlogging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Global Exception Handling & Structured Logging demo.
 *
 * Run with: mvn spring-boot:run
 * Or build a jar: mvn clean package  ->  java -jar target/exception-logging-demo.jar
 */
@SpringBootApplication
public class ExceptionLoggingDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExceptionLoggingDemoApplication.class, args);
    }
}
