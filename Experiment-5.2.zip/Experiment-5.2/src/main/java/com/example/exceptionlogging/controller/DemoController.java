package com.example.exceptionlogging.controller;

import com.example.exceptionlogging.exception.CustomValidationException;
import com.example.exceptionlogging.exception.ResourceNotFoundException;
import com.example.exceptionlogging.model.User;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A small in-memory "Users" API used purely to demonstrate:
 *  - normal successful responses (logged by RequestLoggingInterceptor)
 *  - ResourceNotFoundException  -> 404
 *  - CustomValidationException  -> 400
 *  - @Valid bean validation     -> 400 with field-level details
 *  - an uncaught RuntimeException / ArithmeticException -> 500 (fallback handler)
 */
@RestController
@RequestMapping("/api/users")
public class DemoController {

    private static final Logger log = LoggerFactory.getLogger(DemoController.class);

    private final Map<Long, User> userStore = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    public DemoController() {
        Long id1 = idGenerator.getAndIncrement();
        Long id2 = idGenerator.getAndIncrement();
        userStore.put(id1, new User(id1, "Aarav Sharma", "aarav@example.com", 28));
        userStore.put(id2, new User(id2, "Priya Singh", "priya@example.com", 24));
    }

    @GetMapping
    public Map<Long, User> getAllUsers() {
        log.info("Fetching all users, count={}", userStore.size());
        return userStore;
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id) {
        log.debug("Looking up user with id={}", id);
        User user = userStore.get(id);
        if (user == null) {
            // Demonstrates ResourceNotFoundException -> handled centrally -> 404
            throw new ResourceNotFoundException("User not found with id: " + id);
        }
        return user;
    }

    @PostMapping
    public User createUser(@Valid @RequestBody User user) {
        // If @Valid fails (blank name, bad email, negative age) Spring throws
        // MethodArgumentNotValidException, caught centrally -> 400 with field details.
        Long id = idGenerator.getAndIncrement();
        user.setId(id);
        userStore.put(id, user);
        log.info("Created user with id={}", id);
        return user;
    }

    @DeleteMapping("/{id}")
    public Map<String, String> deleteUser(@PathVariable Long id) {
        if (!userStore.containsKey(id)) {
            throw new ResourceNotFoundException("Cannot delete. User not found with id: " + id);
        }
        userStore.remove(id);
        Map<String, String> result = new HashMap<>();
        result.put("message", "User with id " + id + " deleted successfully");
        return result;
    }

    @PostMapping("/validate-age")
    public Map<String, Object> validateAge(@RequestParam int age) {
        // Demonstrates a manual business-rule check -> CustomValidationException -> 400
        if (age < 18) {
            throw new CustomValidationException("Age must be 18 or older. Provided: " + age);
        }
        Map<String, Object> result = new HashMap<>();
        result.put("message", "Age is valid");
        result.put("age", age);
        return result;
    }

    @GetMapping("/test/divide")
    public Map<String, Integer> divide(@RequestParam int a, @RequestParam int b) {
        // Deliberately uncaught -> ArithmeticException on b=0 -> generic 500 handler
        int result = a / b;
        Map<String, Integer> body = new HashMap<>();
        body.put("result", result);
        return body;
    }

    @GetMapping("/test/error")
    public String triggerUnexpectedError() {
        // Deliberately uncaught -> generic 500 handler, logs full stack trace
        throw new RuntimeException("Simulated unexpected failure for testing the fallback handler");
    }
}
