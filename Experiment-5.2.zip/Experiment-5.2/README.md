# Global Exception Handling & Structured Logging — Spring Boot Demo

Practical implementation for: **Global Exception Handling + Structured Logging with Correlation IDs (CO3 – BT3)**

## What this project demonstrates

| Objective | Where it's implemented |
|---|---|
| Centralized exception handling (`@ControllerAdvice`) | `exception/GlobalExceptionHandler.java` |
| Custom exception classes | `exception/ResourceNotFoundException.java`, `exception/CustomValidationException.java` |
| Standardized error response structure | `dto/ErrorResponse.java` |
| Request logging via Filter | `filter/CorrelationIdFilter.java` |
| Request logging via Interceptor (timing, status) | `interceptor/RequestLoggingInterceptor.java` + `config/WebConfig.java` |
| Correlation ID / MDC request tracing | `CorrelationIdFilter` + `logback-spring.xml` (`%X{correlationId}`) |
| Structured logging (SLF4J + Logback, console + rolling file) | `resources/logback-spring.xml` |

## Project structure

```
exception-logging-demo/
├── pom.xml
├── README.md
└── src/main/
    ├── java/com/example/exceptionlogging/
    │   ├── ExceptionLoggingDemoApplication.java
    │   ├── controller/DemoController.java
    │   ├── model/User.java
    │   ├── exception/
    │   │   ├── ResourceNotFoundException.java
    │   │   ├── CustomValidationException.java
    │   │   └── GlobalExceptionHandler.java
    │   ├── dto/ErrorResponse.java
    │   ├── filter/CorrelationIdFilter.java
    │   ├── interceptor/RequestLoggingInterceptor.java
    │   └── config/WebConfig.java
    └── resources/
        ├── application.properties
        └── logback-spring.xml
```

## Prerequisites

- JDK 17 or later
- Maven 3.6+ (or use your IDE's built-in Maven support)
- Postman / curl for testing

## How to run

```bash
cd exception-logging-demo
mvn spring-boot:run
```

or build a runnable jar:

```bash
mvn clean package
java -jar target/exception-logging-demo.jar
```

The app starts on **http://localhost:8080**.

## How the request flow works (order of execution)

```
Incoming request
   → CorrelationIdFilter        (assigns/reuses correlation ID, puts in MDC, sets response header)
   → RequestLoggingInterceptor  (preHandle: logs method + URI + start time)
   → DemoController             (business logic — may throw an exception)
   → GlobalExceptionHandler     (only if an exception was thrown — builds uniform ErrorResponse)
   → RequestLoggingInterceptor  (afterCompletion: logs final status + execution time)
   → CorrelationIdFilter        (finally block: clears MDC)
```

Because the correlation ID lives in MDC for the whole request lifecycle, **every log line
printed anywhere during that request** — in the filter, interceptor, controller, or exception
handler — automatically carries the same `correlationId`, so you can `grep` one request's
complete story out of the log file.

## Test endpoints

### 1. Successful requests (normal logging)
```bash
curl -i http://localhost:8080/api/users
curl -i http://localhost:8080/api/users/1
```

### 2. ResourceNotFoundException → HTTP 404
```bash
curl -i http://localhost:8080/api/users/999
```
```json
{
  "timestamp": "2026-09-15 10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "User not found with id: 999",
  "path": "/api/users/999",
  "correlationId": "3f1c2a3e-7b2e-4c3d-9f0a-1a2b3c4d5e6f",
  "details": null
}
```

### 3. Bean validation failure (@Valid) → HTTP 400
```bash
curl -i -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "", "email": "not-an-email", "age": -5}'
```
Returns field-level `details` array listing every failed constraint.

### 4. Custom business validation → HTTP 400
```bash
curl -i -X POST "http://localhost:8080/api/users/validate-age?age=15"
```

### 5. Uncaught exception (fallback handler) → HTTP 500
```bash
curl -i http://localhost:8080/api/users/test/error
curl -i "http://localhost:8080/api/users/test/divide?a=10&b=0"
```

### 6. Supplying your own correlation ID (simulating a call chain)
```bash
curl -i http://localhost:8080/api/users/1 -H "X-Correlation-Id: my-trace-123"
```
The same value comes back in the `X-Correlation-Id` response header and in every
log line for that request.

## Sample structured log output

```
2026-09-15 10:30:00.123 [http-nio-8080-exec-1] INFO  [correlationId=3f1c2a3e-7b2e-4c3d-9f0a-1a2b3c4d5e6f] c.e.e.interceptor.RequestLoggingInterceptor - Incoming request -> GET /api/users/999 from 127.0.0.1
2026-09-15 10:30:00.125 [http-nio-8080-exec-1] DEBUG [correlationId=3f1c2a3e-7b2e-4c3d-9f0a-1a2b3c4d5e6f] c.e.e.controller.DemoController - Looking up user with id=999
2026-09-15 10:30:00.126 [http-nio-8080-exec-1] WARN  [correlationId=3f1c2a3e-7b2e-4c3d-9f0a-1a2b3c4d5e6f] c.e.e.exception.GlobalExceptionHandler - Resource not found: User not found with id: 999
2026-09-15 10:30:00.128 [http-nio-8080-exec-1] INFO  [correlationId=3f1c2a3e-7b2e-4c3d-9f0a-1a2b3c4d5e6f] c.e.e.interceptor.RequestLoggingInterceptor - Completed request -> GET /api/users/999 | status=404 | durationMs=5
```

Logs are also written to a rolling file at `logs/application.log` (created automatically on first run).

## Key takeaways for the practical writeup

1. **Why `@ControllerAdvice`?** It removes duplicated try/catch blocks from every controller
   method and guarantees every error response — no matter which controller or exception —
   has the exact same JSON shape.
2. **Why a Filter *and* an Interceptor?** The filter runs at the servlet level, before Spring's
   `DispatcherServlet`, so it's the earliest place to set up cross-cutting state (the correlation
   ID) that everything downstream — including exception handling — depends on. The interceptor
   runs inside the Spring MVC dispatch cycle, giving access to the resolved handler method and a
   clean `afterCompletion` hook for timing/status logging.
3. **Why MDC?** `MDC` (Mapped Diagnostic Context) is thread-local storage that Logback reads on
   every log call. Populating it once per request means you never have to manually pass a
   correlation ID into every `log.info(...)` call — it's automatic.
4. **Observability payoff:** given a user-reported error with a correlation ID (returned in the
   API response), an engineer can instantly `grep` the log file for that ID and see the complete
   request lifecycle — no distributed tracing tool required for a single-service demo.
